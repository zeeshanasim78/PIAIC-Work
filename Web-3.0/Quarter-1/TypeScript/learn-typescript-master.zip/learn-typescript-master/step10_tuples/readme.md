# Tuples

[Tuples](https://www.w3schools.com/typescript/typescript_tuples.php)