import a from "./first.js";
import {b, c} from "./second.js";

console.log(a + b + c);
