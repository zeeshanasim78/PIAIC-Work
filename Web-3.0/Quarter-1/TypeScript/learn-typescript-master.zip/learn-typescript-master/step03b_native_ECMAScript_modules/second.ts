const b = 10;

const c = 2;

export {b, c};