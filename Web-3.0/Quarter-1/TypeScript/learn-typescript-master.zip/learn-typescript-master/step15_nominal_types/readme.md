Read:

Nominative and structural type systems
http://en.wikipedia.org/wiki/Nominative_and_structural_type_systems

https://michalzalecki.com/nominal-typing-in-typescript/

https://betterprogramming.pub/nominal-typescript-eee36e9432d2

https://byby.dev/ts-nominal-typing


