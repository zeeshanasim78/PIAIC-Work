# Object Types

[Object Types](https://www.typescriptlang.org/docs/handbook/2/objects.html)