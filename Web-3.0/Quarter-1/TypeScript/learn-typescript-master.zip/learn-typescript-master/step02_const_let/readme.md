# Variable Declaration

[Variable Declaration](https://www.typescriptlang.org/docs/handbook/variable-declarations.html)