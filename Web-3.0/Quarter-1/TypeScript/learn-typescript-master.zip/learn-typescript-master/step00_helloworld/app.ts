let message = "Hello World";// Infering Types, 
                            //take your cursor on the variable name
console.log(message);
        
