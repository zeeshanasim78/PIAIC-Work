Read:
http://www.typescriptlang.org/Handbook#interfaces-optional-properties