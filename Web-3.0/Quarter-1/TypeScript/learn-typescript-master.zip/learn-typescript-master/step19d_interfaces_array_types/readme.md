Read:
http://www.typescriptlang.org/Handbook#interfaces-array-types
https://github.com/Microsoft/TypeScript/wiki/Interfaces
http://blogs.msdn.com/b/typescript/archive/2013/01/24/interfaces-walkthrough.aspx
