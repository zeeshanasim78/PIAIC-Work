Read this:
Chapter 8 of Learning TypeScript
http://www.amazon.com/Learning-TypeScript-Remo-H-Jansen/dp/1783985542/ref=sr_1_1

http://blog.wolksoftware.com/decorators-metadata-reflection-in-typescript-from-novice-to-expert-part-4

Command:
tsc -target es5 -module commonjs -emitDecoratorMetadata -experimentalDecorators app.ts

