# Functions

[More on Functions](https://www.typescriptlang.org/docs/handbook/2/functions.html)