Read:
https://www.typescriptlang.org/docs/handbook/2/classes.html#member-visibility

https://www.typescriptlang.org/docs/handbook/2/classes.html#private