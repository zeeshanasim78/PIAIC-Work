# Strong Typing

[Read Everyday Types](https://www.typescriptlang.org/docs/handbook/2/everyday-types.html)

