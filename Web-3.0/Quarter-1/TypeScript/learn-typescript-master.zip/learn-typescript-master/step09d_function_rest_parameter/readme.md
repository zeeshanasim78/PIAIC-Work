# Rest Parameters

[Rest Parameters in TypeScript](https://www.geeksforgeeks.org/rest-parameters-in-typescript/)