# Object Types

[Object Types](https://www.typescriptlang.org/docs/handbook/2/objects.html)

[Type Aliases](https://www.typescriptlang.org/docs/handbook/2/everyday-types.html#type-aliases)


[Type vs. Interfaces](https://www.typescriptlang.org/docs/handbook/2/everyday-types.html#interfaces)