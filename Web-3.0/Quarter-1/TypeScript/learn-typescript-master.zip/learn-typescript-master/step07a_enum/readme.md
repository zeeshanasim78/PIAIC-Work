# Enums

[Enums](https://www.typescriptlang.org/docs/handbook/enums.html)

