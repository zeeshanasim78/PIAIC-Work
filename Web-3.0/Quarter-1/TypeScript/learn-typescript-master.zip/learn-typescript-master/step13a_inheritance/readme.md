Read:

https://www.typescriptlang.org/docs/handbook/2/classes.html#class-heritage
