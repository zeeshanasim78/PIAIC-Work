# Explicit Casting

[Casting](https://www.w3schools.com/typescript/typescript_casting.php)

[Type Casting in TypeScript](https://www.codingninjas.com/codestudio/library/type-casting-in-typescript)

