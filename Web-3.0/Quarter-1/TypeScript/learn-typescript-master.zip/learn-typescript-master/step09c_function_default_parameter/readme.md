# Default Parameters

[TypeScript Default Parameters](https://www.typescripttutorial.net/typescript-tutorial/typescript-default-parameters/)