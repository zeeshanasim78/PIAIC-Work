# Callback Function

[Define Type for Function Callbacks in TypeScript](https://www.delftstack.com/howto/typescript/typescript-function-type/)