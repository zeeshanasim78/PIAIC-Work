# Object Intersection Types

[What are intersection types in Typescript](https://www.geeksforgeeks.org/what-are-intersection-types-in-typescript/)