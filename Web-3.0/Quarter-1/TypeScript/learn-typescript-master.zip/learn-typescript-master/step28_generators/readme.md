Read:
https://github.com/Microsoft/TypeScript/issues/2873

http://www.dotnetcurry.com/javascript/1131/ecmascript6-async-using-generators-promises