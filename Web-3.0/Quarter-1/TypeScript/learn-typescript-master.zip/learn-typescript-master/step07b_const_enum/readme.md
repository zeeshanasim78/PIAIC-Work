# Const Enums

[Const Enums](https://www.typescriptlang.org/docs/handbook/enums.html#const-enums)
