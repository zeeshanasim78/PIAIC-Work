let a = 5;

export default a;