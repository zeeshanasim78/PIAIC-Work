export const b = 10;

export const c = 2;