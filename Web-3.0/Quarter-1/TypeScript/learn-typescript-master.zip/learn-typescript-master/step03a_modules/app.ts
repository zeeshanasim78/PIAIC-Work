import a from "./first";
import {b, c as d} from "./second";

console.log(a + b + d);
