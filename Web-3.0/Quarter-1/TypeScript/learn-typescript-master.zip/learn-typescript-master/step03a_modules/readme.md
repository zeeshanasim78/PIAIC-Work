# Modules in TypeScript

[Modules](https://www.typescriptlang.org/docs/handbook/2/modules.html)

[ECMAScript Modules in Node.js](https://www.typescriptlang.org/docs/handbook/esm-node.html)

When we transpile this program it runs correctly.

However, note that the transpiled JavaScript code doesnot use
the ES Module sytax but rather the old commonjs syntax.