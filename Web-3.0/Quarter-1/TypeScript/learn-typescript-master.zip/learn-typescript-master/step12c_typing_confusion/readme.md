Read:

https://github.com/Microsoft/TypeScript/issues/5303

https://www.typescriptlang.org/docs/handbook/type-compatibility.html

http://www.typescriptlang.org/Handbook#classes-classes

http://basarat.gitbooks.io/typescript/content/docs/classes.html

https://www.tektutorialshub.com/typescript/structural-typing-duck-typing-in-typescript/

https://imfaber.me/typescript-structural-typing/
