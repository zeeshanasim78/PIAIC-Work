# Optional Parameters

[Optional Parameters](https://www.typescripttutorial.net/typescript-tutorial/typescript-optional-parameters/)