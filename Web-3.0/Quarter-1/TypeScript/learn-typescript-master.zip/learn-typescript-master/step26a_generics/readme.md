Read:
http://www.typescriptlang.org/Handbook#generics
http://blogs.msdn.com/b/rmattsampson/archive/2015/01/01/typescript-generic-collection-implementation-it-s-you-know-generic.aspx