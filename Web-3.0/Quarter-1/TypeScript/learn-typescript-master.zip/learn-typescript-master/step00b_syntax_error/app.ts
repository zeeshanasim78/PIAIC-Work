lett message = "Hello World";//syntax error
console.log(message);
        
