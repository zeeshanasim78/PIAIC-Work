# Syntax Error

		tsc app.ts

The Output:

		app.ts:1:1 - error TS1435: Unknown keyword or identifier. Did you mean 'let'?

		1 lett message = "Hello World";//syntax error
  ~~~~

		Found 1 error in app.ts:1



Note that .js file has been generated but it is not valid.

