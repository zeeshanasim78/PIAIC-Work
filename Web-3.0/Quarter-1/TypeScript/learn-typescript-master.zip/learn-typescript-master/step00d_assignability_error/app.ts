let message = "Hello World";
message = 6;
console.log(message);
        
