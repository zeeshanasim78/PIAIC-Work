# Function Overloads

[Function Overloads](https://www.typescriptlang.org/docs/handbook/2/functions.html#function-overloads)