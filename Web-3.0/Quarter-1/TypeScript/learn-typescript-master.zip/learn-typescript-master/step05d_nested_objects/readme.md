# Nested Objects

[Declare and Type a nested Object in TypeScript](https://bobbyhadz.com/blog/typescript-type-nested-object)