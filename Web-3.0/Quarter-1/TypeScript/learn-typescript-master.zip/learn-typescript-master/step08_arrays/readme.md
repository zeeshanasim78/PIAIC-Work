# Arrays

[Arrays](https://www.typescriptlang.org/docs/handbook/2/everyday-types.html#arrays)

[20 Array methods in Typescript you need to know with examples](https://blog.canopas.com/typescript-array-methods-and-their-usages-daa8d498b4fd)

